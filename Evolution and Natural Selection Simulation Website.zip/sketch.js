// The Nature of Code
// Daniel Shiffman
// http://natureofcode.com

// Stay Within Walls
// "Made-up" Steering behavior to stay within walls

let img;
mice_and_eagle = false;

function mice_and_eagle_set() {
  mice_and_eagle = true;
  setup();
}

let input1, input2, button, greeting;

var cnv;

let v;

let debug = false;

let d = 25;

mice = [];

eagles = [];

var miceCounter = 0;

var mutationRate = 0.1;

var eagleValue;
var miceValue;

var firstRun = true;

var matingRate = 0.001

function centerCanvas() {
  var x = (windowWidth - width) / 2;
  var y = (windowHeight - height) / 2;
  cnv.position(x, y);
}

function setup() {
  img = loadImage('Artificial-fake-green-grass-Background-Vinyl-cloth-High-quality-Computer-print-wall-photo-backdrop.jpg');
  cnv = createCanvas(windowWidth / 2, windowHeight);
  centerCanvas();
  if(firstRun) {
    firstRun = false;
  numEagles = createElement('h4', 'Eagles:');
  numEagles.position(1200,25);
  
  input1 = createInput('1');
  input1.position(1200, 65);
   
  numMice = createElement('h4', 'Mice:');
  numMice.position(1200,65);
  input2 = createInput('50');
  input2.position(1200,105);
    
  mutationRate = createElement('h4','RadiationRate:');
  mutationRate.position(1200,135);
  input3 = createInput('not implemented yet');
  input3.position(1200,175);
    
  matingRate = createElement('h4','MatingRate:');
  matingRate.position(1200,200);
  input3 = createInput('not implemented yet');
  input3.position(1200,235);

  button = createButton('Run');
  button.position(input2.x, input2.y + 20);
  button.mousePressed(mice_and_eagle_set);
  }

  textAlign(CENTER);
  textSize(50);
  
  eagleValue = input1.value();
  miceValue = input2.value();


  if (mice_and_eagle) {
    print(eagleValue);
    for(var i = 0 ; i < eagleValue; i++) {
      eagles[i] = new eagleObj(random(width), random(height));
      print(eagles[i]);
    }
    
    mice = [];
    for (var i = 0; i < miceValue; i++) {
      mice[i] = new mouseObj(random(width), random(height), random(255), random(255), random(255));
    }
  }
}

function windowResized() {
  centerCanvas();
}

function draw() {
  text(mice.length, 1200, 600);
  if (mice_and_eagle)
    miceAndEagle();

}

function keyTyped() {
  if (key === 'd') {
    debug = !debug;
  }
}

function miceAndEagle() {
  background(0,230,0);
  // background(img);

  let pointer = createVector(mouseX, mouseY);

  if (debug) {
    stroke(175);
    noFill();
    rectMode(CENTER);
    rect(width / 2, height / 2, width - d * 2, height - d * 2);
  }

  // Call the appropriate steering behaviors for our agents
  for (var i = 0; i < mice.length; i++) {
    mice[i].boundaries();
    // mice[i].arrive(pointer);
    for(var j = 0; j < eagleValue; j++) {
    mice[i].avoid(eagles[j].position);
    }
    mice[i].update();
    mice[i].boundaries();
    mice[i].display();
    cross(mice[i]);

  }
  for(var i = 0; i < eagleValue; i++) {
  eagles[i].update();
  // the_eagle.arrive(pointer);
  if (mice.length != miceCounter) {
    score = -mice[miceCounter].red /255 + mice[miceCounter].green /255 + -mice[miceCounter].blue/255;
    // mice.length != 0 && mice[miceCounter].red < 120 && mice[miceCounter].green > 200 && mice[miceCounter].blue < 120 
    if (random(1) < score) {
      miceCounter++;
    } else {
    // eagles[i].attack2(mice);

      eagles[i].attack(mice[miceCounter]);
      if (Math.abs(eagles[i].position.x - mice[miceCounter].position.x) < 6 && Math.abs(eagles[i].position.y - mice[miceCounter].position.y) < 6) {
        mice.splice(miceCounter, 1);
      }
    }
  }
  else {
    eagles[i].stop();
  }

  
//   if (mice.length != 0 && mice[miceCounter].red < 120 && mice[miceCounter].green > 200 && mice[miceCounter].blue < 120){
  
  print(mice.length);
  // the_eagle.boundaries();
  
  eagles[i].display();
  }
}

function cross(mouse) {
    for(var i = 0; i < mice.length; i++) {
       if(Math.abs(mouse.position.x - mice[i].position.x) < 1 && Math.abs(mouse.position.y - mice[i].position.y) < 1 && random(1/matingRate) < 1) {
      if(random(1) < mutationRate) {
        print(mutationRate);
        mice.push(new mouseObj(random(width), random(height), random(255), random(255), random(255)));
      }
         else {
          mice.push(new mouseObj((mouse.position.x+mice[i].position.x) / 2, (mouse.position.y+mice[i].position.y) / 2,(mouse.red + mice[i].red)/2,(mouse.green + mice[i].green)/2,(mouse.blue + mice[i].blue)/2))
          }
       }
    }
  
}